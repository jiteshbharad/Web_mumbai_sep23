window.addEventListener("load",function(){
});

function drawFilledRect()
{
    let canvObj = document.getElementById('container');
    let ctx = canvObj.getContext("2d");
    ctx.fillStyle="rgb(0,0,255)";
    ctx.fillRect(50,50,200,100);
}

function drawStrokeRect()
{
    let canvObj = document.getElementById('container');
    let ctx = canvObj.getContext("2d");
    ctx.strokeStyle="rgb(255,0,0)";
    ctx.lineWidth=2;
    ctx.strokeRect(280,180,200,100);
}

function clearRectI()
{
    let canvObj = document.getElementById('container');
    let ctx = canvObj.getContext("2d");
    ctx.clearRect(50,50,200,100);    
}

function clearRectIPartially()
{
    let canvObj = document.getElementById('container');
    let ctx = canvObj.getContext("2d");
    ctx.clearRect(70,80,20,20);
}